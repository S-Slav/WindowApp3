package EmployeeManagement;

public enum EmployeeCondition {
    present,
    business_trip,
    sick,
    absent
}
