package EmployeeManagement;

public class Main {

    public static void main(String[] args) {

//        Employee JanK = new Employee("Jan", "Kowalski", EmployeeCondition.present, 2000, 3000);
//        Employee AdamK = new Employee("Adam", "Kowalski", EmployeeCondition.sick, 2001, 3001);
//        Employee StefanK = new Employee("Stefan", "Kowal", EmployeeCondition.absent, 2002, 3002);
//        Employee StefanA = new Employee("Stefan", "Adamczyk", EmployeeCondition.present, 2003, 3003);
//        JanK.printing();
//        JanK.changeCondition(EmployeeCondition.business_trip);
//        ClassEmployee Group1 = new ClassEmployee("Group1",10);
//        Group1.addEmployee(JanK);
//        Group1.addEmployee(StefanK);
//        Group1.addEmployee(AdamK);
//        Group1.addEmployee(StefanA);
//        Group1.addSalary(JanK,5);
//        Group1.addSalary(JanK,-5);
//        Group1.search("Kowalski");
//        Group1.searchPartial("Kowal");
//        Group1.countByCondition(EmployeeCondition.present);
//        Group1.summary();
//        Group1.sortByName();
//        Group1.sortBySalary();
//        Group1.largestSalary();
//        Group1.removeEmployee(JanK);
//        Group1.addSalary(JanK,-5);
//        Employee JakubA = new Employee("Jakub", "Adamczyk", EmployeeCondition.present, 2004, 3004);
//        ClassContainer classContainer = new ClassContainer();
//        ClassEmployee Group2 = new ClassEmployee("Group2",15);
//        Group2.addEmployee(JakubA);
//        classContainer.addClass(Group1);
//        classContainer.addClass(Group2);
//        classContainer.summary();
//        classContainer.printEmpty();
//        classContainer.removeClass(Group1);
//        //extra
//        ClassEmployee Group3 = Group1.mergeGroups(Group2,"MGroups");
//        Group3.summary();
//        classContainer.getTotalEmployeeCount();
//        classContainer.removeEmployeeFromGroup("Group1", AdamK);
//        classContainer.getTotalEmployeeCount();
//        Group1.clearGroup();
//        Employee Copy = JanK.copy();
//        Copy.getFullName();
//        classContainer.renameGroup(Group1.GroupName, "Test");
//        classContainer.summary();
    }

}
